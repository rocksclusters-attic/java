package org.antlr.test;

public class DebugTestRewriteAST extends TestRewriteAST {
	public DebugTestRewriteAST() {debug=true;}
}

