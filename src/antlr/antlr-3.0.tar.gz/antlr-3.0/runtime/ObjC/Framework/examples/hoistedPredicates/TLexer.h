// $ANTLR 3.0b6 T.g 2007-02-01 01:27:59

#import <Cocoa/Cocoa.h>
#import <ANTLR/ANTLR.h>

#pragma mark Cyclic DFA start
#pragma mark Cyclic DFA end

#pragma mark Rule return scopes start
#pragma mark Rule return scopes end

#pragma mark Tokens
#define TLexer_INT	5
#define TLexer_EOF	-1
#define TLexer_WS	6
#define TLexer_Tokens	8
#define TLexer_T7	7
#define TLexer_ID	4

@interface TLexer : ANTLRLexer {
}


- (void) mT7;
- (void) mID;
- (void) mINT;
- (void) mWS;
- (void) mTokens;



@end