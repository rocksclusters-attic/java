#ifndef	_ANTLR3_STRINGSTREAM_H
#define	_ANTLR3_STRINGSTREAM_H

#include    <antlr3defs.h>


#endif
