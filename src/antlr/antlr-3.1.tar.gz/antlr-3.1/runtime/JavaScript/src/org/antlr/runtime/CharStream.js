org.antlr.runtime.CharStream = {
    EOF: -1
};
