This is a dummy README file for the sample
web application.
